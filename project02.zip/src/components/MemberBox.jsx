const MemberBox=({teamName,memberName})=>{
        return(
            <div style={{ border:'1px solid black',margin:'2%',padding:'2%'}}>
            <h2>{teamName}</h2>
            <p>{memberName}</p>
           </div> 


        )

}
export default MemberBox